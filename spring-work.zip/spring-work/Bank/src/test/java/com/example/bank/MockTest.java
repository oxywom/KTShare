package com.example.bank;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.handler;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import javax.servlet.http.Cookie;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.example.bank.controller.AccountController;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class MockTest {
	   @Autowired
	    private MockMvc mockMvc;
	    
	    @Test
	    public void testAdd() throws Exception {
	    	 MultiValueMap<String, String> info = new LinkedMultiValueMap<>();

	    	 info.add("x", "10");
	    	 info.add("y", "20");
	    	 Cookie cookie = new Cookie("name", "홍길동");
	    	    
	    	    
	    	 MockHttpServletRequestBuilder builder = get("/add").params(info).cookie(cookie);
	    	    
	    	 ResultActions result = mockMvc.perform(builder);
	    	    result.andExpect(handler().handlerType(AccountController.class))
	    	    	.andExpect(handler().methodName("add"))
	    	    	.andExpect(model().attribute("result", Double.valueOf(30.0)))
	    	    	.andExpect(view().name("testview"))
	    	    	.andExpect(status().isOk())
	    	    	.andDo(print());
	    }
	    @Test
	    public void testBlog() throws Exception {
	        MultiValueMap<String, String> info = new LinkedMultiValueMap<>();

	        info.add("name", "칩");
	        info.add("id", "chip");

	        mockMvc.perform(get("/blog")       // 1, 2
	            .params(info))              // 3
	            .andExpect(status().isOk())     // 4
	            .andExpect(content().string("칩의 블로그입니다. chip"))  
	            .andDo(print()); 	    	
	    }
}
