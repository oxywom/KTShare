package com.example.moc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockExApplicationTests {

	@Test
	void contextLoads() {
	}

}
