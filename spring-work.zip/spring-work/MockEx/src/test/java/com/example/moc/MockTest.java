package com.example.moc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.handler;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import javax.servlet.http.Cookie;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class MockTest {
	@Autowired
	MockMvc mockMvc;
	
	@Test
	public void testAdd() throws Exception {
		MultiValueMap<String, String> info =
				new LinkedMultiValueMap<>();
		info.add("x", "10");
		info.add("y", "20");
		
		Cookie cookie = new Cookie("name","홍길동");
		
		MockHttpServletRequestBuilder builder=get("/add").params(info).cookie(cookie);
		ResultActions result = mockMvc.perform(builder);
		result.andExpect(handler().handlerType(MyController.class))
			.andExpect(handler().methodName("add"))
			.andExpect(model().attribute("result", Double.valueOf(30.0)))
			.andExpect(view().name("testview"))
			.andExpect(status().isOk())
			.andDo(print());
		
//		mockMvc.perform(get("/add").params(info).cookie(cookie))
//		 .andExpect(handler().handlerType(MyController.class))
//			.andExpect(handler().methodName("add"))
//			.andExpect(model().attribute("result", Double.valueOf(30.0)))
//			.andExpect(view().name("testview"))
//			.andExpect(status().isOk())
//			.andDo(print());
	}
	
	@Test
	public void testBlog() throws Exception {
		MultiValueMap<String, String> info =
				new LinkedMultiValueMap<String, String>();
		info.add("name", "홍");
		info.add("id", "hong");
		
		mockMvc.perform(get("/blog").params(info))
			.andExpect(status().isOk())
			.andExpect(content().string("홍의 블로그입니다. hong"))
			.andDo(print());
	}
}







