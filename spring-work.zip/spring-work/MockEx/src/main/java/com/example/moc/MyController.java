package com.example.moc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	@GetMapping("/add")
	public String add(@RequestParam Double x,@RequestParam Double y,
			@CookieValue(required=false) String name, Model model) {
		model.addAttribute("result", x+y);
		model.addAttribute("name", name);
		return "testview";
	}
	
	@GetMapping("/blog")
	@ResponseBody
	public String blogGet(@RequestParam String name, 
			@RequestParam String id) {
		return name+"의 블로그입니다. "+id;
	}
}




