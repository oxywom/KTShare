package com.example.join.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.join.dto.MemberDto;
import com.example.join.dto.TeamDto;
import com.example.join.entity.Member;
import com.example.join.entity.Team;
import com.example.join.repository.MemberRepository;
import com.example.join.repository.TeamRepository;

@Service
public class MainService {
	@Autowired
	private TeamRepository teamRepository;
	@Autowired
	private MemberRepository memberRepository;	
	
	ModelMapper modelMapper = new ModelMapper();

	public void regTeam(Team team) throws Exception {
		teamRepository.save(team);
	}
	
	public void regMember(Integer id, String name, 
			String teamName) throws Exception {
		Optional<Team> oteam = 
				teamRepository.findByName(teamName);
		if(oteam.isEmpty()) throw new Exception("팀명오류");
		Member member=
				Member.builder().id(id).name(name).build();
		member.setTeam(oteam.get());
		memberRepository.save(member);
	}
	
	public MemberDto memberInfo(Integer id) throws Exception {
		Optional<Member> omember=
				memberRepository.findById(id);
		if(omember.isEmpty()) throw new Exception("멤버번호오류");
		Member member=omember.get();
		MemberDto mdto = modelMapper.map(member, MemberDto.class);
//		MemberDto mdto = new MemberDto(member.getId(),
//				member.getName(),member.getTeam().getId(),
//				member.getTeam().getName());
		return mdto;
	}
	
	public List<TeamDto> teamList() throws Exception {
		List<Team> list= teamRepository.findAll();
		List<TeamDto> teamList = 
			list.stream().map(
			team -> modelMapper.map(team,TeamDto.class)).collect(
					Collectors.toList());
//		List<TeamDto> teamList = new ArrayList<>();
//		for(Team t :list) {
//			teamList.add(new TeamDto(t.getId(),t.getName()));
//		}
		return teamList;
	}
	
	public List<MemberDto> 
		memberList(String teamName) throws Exception {
		Optional<Team> oteam = 
				teamRepository.findByName(teamName);
		if(oteam.isEmpty()) throw new Exception("팀명 오류");
		Team team = oteam.get();
		List<Member> list= team.getMembers();
		List<MemberDto> members = 
			list.stream().map(member -> modelMapper.map(member, MemberDto.class))
				.collect(Collectors.toList());
//		List<MemberDto> members = new ArrayList<>();
//		for(Member m: list) {
//			members.add(new MemberDto(m.getId(),m.getName(),
//					team.getId(), team.getName()));
//		}
		return members;
	}
}




