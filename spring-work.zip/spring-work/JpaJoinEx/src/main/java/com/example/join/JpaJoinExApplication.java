package com.example.join;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaJoinExApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaJoinExApplication.class, args);
	}

}
