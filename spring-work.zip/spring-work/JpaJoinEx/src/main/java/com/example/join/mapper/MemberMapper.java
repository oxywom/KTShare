package com.example.join.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.example.join.dto.MemberDto;
import com.example.join.entity.Member;

@Mapper
public interface MemberMapper {
	MemberMapper INSTANCE = Mappers.getMapper( MemberMapper.class ); 
    
    @Mapping(source = "member.team.id", target = "team_id")
    @Mapping(source = "member.team.name", target = "team_name")
    MemberDto memberToMemberDto(Member member); 
}
