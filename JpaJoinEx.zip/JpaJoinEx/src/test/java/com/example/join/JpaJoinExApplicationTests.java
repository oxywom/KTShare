package com.example.join;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.join.entity.Member;
import com.example.join.entity.Team;
import com.example.join.repository.MemberRepository;
import com.example.join.repository.TeamRepository;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class JpaJoinExApplicationTests {

	@Autowired
	private MemberRepository memberRepository;
	
	@Autowired
	private TeamRepository teamRepository;
	@Test
	void insertTeam() {
		Team team = new Team(2,"KTDS");
		teamRepository.save(team);
	}
	
	@Test
	void selectMember() {
		Member member = memberRepository.findById(10).get();
		System.out.println(member);
	}
	
	@Test
	void insertMember() {
		Team team = teamRepository.findByName("KTDS");
		Member member = new Member(11,"하길동",team);
		memberRepository.save(member);
	}
}





