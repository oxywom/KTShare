package com.example.board.controler;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.example.board.entity.Board;
import com.example.board.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardSerive;
	
	@GetMapping("/writeform")
	public String writeForm() {
		return "writeform";
	}
	
	@PostMapping("/boardwrite")
	public ModelAndView boardWrite(@ModelAttribute Board board,
			@RequestParam(name="file",required=false) MultipartFile file) {
		ModelAndView mv = new ModelAndView();
		try {
			boardSerive.writeBoard(board, file);
			mv.setViewName("redirect:/boardlist");
		} catch(Exception e) {
			e.printStackTrace();
			mv.setViewName("error");
		}
		return mv;
	}
	
	@GetMapping("/boardlist")
	public ModelAndView boardList() {
		ModelAndView mv = new ModelAndView();
		try {
			List<Board> boards = boardSerive.boardList();
			mv.addObject("boards", boards);
			mv.setViewName("boardlist");
		} catch(Exception e) {
			mv.setViewName("error");
		}
		return mv;
	}
	
	@GetMapping("/detailform/{num}")
	public String detailForm(@PathVariable Integer num, Model model) {
		try {
			Board board = boardSerive.detailBoard(num);
			model.addAttribute("board", board);
			return "detailform";
		} catch(Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
	
	@GetMapping("/image/{filename}")
	public void imageView(@PathVariable String filename, HttpServletResponse response) {
		String path = "C:/LectureMaterials/KT/upload/"; 
		try {
			FileInputStream fis = new FileInputStream(path+filename);
			OutputStream out = response.getOutputStream();
			FileCopyUtils.copy(fis, out);
			fis.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@GetMapping("/delete/{num}")
	public ModelAndView deleteBoard(@PathVariable Integer num) {
		ModelAndView mv = new ModelAndView();
		try {
			boardSerive.deleteBoard(num);
			mv.setViewName("redirect:/boardlist");
		} catch(Exception e) {
			e.printStackTrace();
			mv.setViewName("error");
		}
		return mv;
	}
	
	@PostMapping("/boardmoify")
	public ModelAndView boardModify(@ModelAttribute Board board) {
		System.out.println(board);
		ModelAndView mv = new ModelAndView();
		try {
			boardSerive.modify(board);
			mv.setViewName("redirect:/boardlist");
		} catch(Exception e) {
			e.printStackTrace();
			mv.setViewName("error");
		}
		return mv;
	}
}
















