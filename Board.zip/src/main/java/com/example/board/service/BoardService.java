package com.example.board.service;

import java.io.File;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.board.entity.Board;
import com.example.board.repository.BoardRepository;

@Service
public class BoardService {
	@Autowired
	private BoardRepository boardRepository;
	public void writeBoard(Board board, MultipartFile file) throws Exception {
		if(file!=null && !file.isEmpty()) {
			String path = "C:/LectureMaterials/KT/upload/";
			File destFile = new File(path+file.getOriginalFilename());
			file.transferTo(destFile);
			board.setFilename(file.getOriginalFilename());
		}
		boardRepository.save(board);
	}
	
	public Board detailBoard(Integer num) throws Exception {
		int updateCnt = boardRepository.readCntInc(num);
		if(updateCnt==0) throw new Exception("글번호 오류");
		Optional<Board> oboard = boardRepository.findById(num);
		return oboard.get();
	}
	
	public void deleteBoard(Integer num) throws Exception {
		boardRepository.deleteById(num);
	}
}









