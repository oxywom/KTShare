package com.example.board.controller;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.board.entity.Board;
import com.example.board.service.BoardService;

@RestController
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	@PostMapping("/write")
	public ResponseEntity<String> writeBoard(@ModelAttribute Board board,
			@RequestParam(name="file", required=false) MultipartFile file) {
		ResponseEntity<String> res = null;
		try {
			boardService.writeBoard(board, file);
			res = new ResponseEntity<String>("글 등록 성공",HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			res = new ResponseEntity<String>("글 등록 실패",HttpStatus.BAD_REQUEST);
		}
		return res;
	}
	
	@GetMapping("/detail")
	public ResponseEntity<Board> detailBoard(
			@RequestParam("num") Integer num) {
		ResponseEntity<Board> res = null;
		try {
			Board board = boardService.detailBoard(num);
			res = new ResponseEntity<Board>(board,HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			res = new ResponseEntity<Board>(HttpStatus.BAD_REQUEST);
		}
		return res;
	}
	
	@GetMapping("/image/{filename}")
	public void imageView(@PathVariable String filename,
			HttpServletResponse response) {
		String path = "C:/LectureMaterials/KT/upload/"; 
		try {
			FileInputStream fis = new FileInputStream(path+filename);
			OutputStream out = response.getOutputStream();
			FileCopyUtils.copy(fis, out);
			fis.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@DeleteMapping("/delete/{num}")
	public ResponseEntity<Boolean> deleteBoard(@PathVariable Integer num) {
		ResponseEntity<Boolean> res = null;
		try {
			boardService.deleteBoard(num);
			res = new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			res = new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
		}
		return res;
	}
	
//	@GetMapping("/boardList")
//	public ResponseEntity<List<Board>> boardList() {
//		
//	}

}








