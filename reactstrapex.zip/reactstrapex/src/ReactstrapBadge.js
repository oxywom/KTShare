import {Badge, Button} from 'reactstrap';

function ReactstrapBadge() {
    return(
        <div>
            <h1>PRODUCT NAME <Badge color="secondary">hit</Badge></h1>
            <Button color="primary" outline>
                Accessor <Badge color="dark">4</Badge>
            </Button>
            <Badge color="danger" pill>pill</Badge>
            <Badge href="http://daum.net" color="primary">GoLink</Badge>
        </div>
    )
}

export default ReactstrapBadge;