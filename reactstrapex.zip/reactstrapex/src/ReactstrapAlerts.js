import {Alert, UncontrolledAlert} from 'reactstrap';

function ReactstrapAlerts() {
    return(
        <div>
            <Alert color="light">
                Simple Alert [color:light]
            </Alert>
            <UncontrolledAlert color="dark">
                UncontrolledAlert [color:dark]
            </UncontrolledAlert>
        </div>
    )
}

export default ReactstrapAlerts;