import 'bootstrap/dist/css/bootstrap.css';
import ReactstrapAlerts from './ReactstrapAlerts';
import ReactstrapBadge from './ReactstrapBadge';
import ReactstrapModal from './ReactstrapModal';
function App() {
  return (
    <div className="App">
      {/* <ReactstrapAlerts/> */}
      {/* <ReactstrapBadge/> */}
      <ReactstrapModal/>
    </div>
  );
}

export default App;
