const express=require('express');
const app=express();
const port=3001;
const url="http://localhost";
const cors=require('cors');
const mysql=require('mysql');

app.use(express.json());
app.use(cors());

app.listen(port,()=>{
    console.log(`Connect at ${url}:${port}`);
});

const con=mysql.createConnection({
    host:"localhost",
    port: "3306",
    user:"root",
    password:"1234",
    database:"kttest"
});

con.connect(function(err) {
    if(err) throw err;
    console.log("Connected!");
});

app.post("/doubleid", function(req,res) {
    const id=req.body.id;
    var sql="select * from account where id=?";
    con.query(sql, [id], function(err,result) {
        if(err) {
            console.log("err:"+err);
            res.status(500).send({res:0});
        } else {
            console.log(result);
            res.send({res:result.length!==0});
        }
    });    
});

app.post("/accinfo", function(req,res) {
    const id=req.body.id;
    var sql="select * from account where id=?";
    con.query(sql, [id], function(err,result) {
        if(err) {
            res.status(500).send({res:0});
        } else {
            res.send({res:result[0]});
        }
    });
});

app.get("/allaccinfo", function(req, res) {
    var sql = "select * from account";
    con.query(sql, function(err,result) {
        if(err) {
            res.status(500).send({res:0});
        } else {
            res.send({res:result});
        }
    });
});

app.post("/makeaccount", function(req, res) {
    const acc= req.body.acc;
    var value=[acc.id,acc.name,acc.balance,acc.type,acc.grade];
    var sql="insert into account(id,name,balance,type,grade) values (?)";
    con.query(sql,[value],function(err,result) {
        if(err) {
            console.log(err);
            res.status(500).send({res:0});
        } else {
            console.log("Number of recoird inserted: "+result.affectedRows);
            res.send({res:true});
        }
    });
});

app.post("/deposit", function(req,res) {
    const acc = req.body.acc;
    console.log(acc);
    var select_sql="select * from account where id=?";
    con.query(select_sql, [acc.id], function(err, result) {
        console.log(result);
        if(err || result.length==0) {
            res.status(500).send({res:0});
            return;
        }
        var update_sql="update account set balance=balance+? where id=?";
        con.query(update_sql,[acc.money,acc.id], function(err1, result1) {
            console.log(result1);
            if(err1) {
                res.status(500).send({res:0});
            } else {
                console.log(+(+(result[0].balance)+(+acc.money)))
                res.send({res:+(+(result[0].balance)+(+acc.money))});
            }
        })
    });
});

app.post("/withdraw", function(req,res) {
    const acc = req.body.acc;
    var select_sql="select * from account where id=?";
    con.query(select_sql, [acc.id], function(err, result) {
        console.log(result);
        if(err || result.length==0) {
            res.status(500).send({res:0});
            return;
        } else if(+(result[0].balance)<+(acc.money)) {
            res.status(500).send({res:0});
            return;
        }
        var update_sql="update account set balance=balance-? where id=?";
        con.query(update_sql,[acc.balance,acc.id], function(err1, result1) {
            console.log(result1);
            if(err1) {
                res.status(500).send({res:0});
            } else {
                console.log(+(+(result[0].balance)-(+acc.money)))
                res.send({res:+(+(result[0].balance)-(+acc.money))});
            }
        })
    });
});