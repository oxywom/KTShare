import React, {useState} from 'react';

export default function FPersonInfo({person}) {
    // const [age, setAge] = useState(person.age);
    // const [name, setName] = useState(person.name);
    const [info, setInfo] = useState({age:person.age, name:person.name});
    const change = (e) => {
        setInfo({...info,[e.target.name]: e.target.value})
    }
    
    return (
        <>
            이름:<input type="text" name="name" onChange={change}/>&nbsp;&nbsp;
            <span>이름:{info.name}</span><br/>
            나이:<input type="text" name="age" onChange={change}/>&nbsp;&nbsp;
            <span>나이:{info.age}</span>&nbsp;&nbsp;         
            {/* 이름:<input type="text" name="name" onChange={e=>setName(e.target.value)}/>&nbsp;&nbsp;
            <span>이름:{info.name}</span><br/>
            나이:<input type="text" name="age" onChange={e=>setAge(e.target.value)}/>&nbsp;&nbsp;
            <span>나이:{info.age}</span>&nbsp;&nbsp;           */}
        </>
    )
}