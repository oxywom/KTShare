import React, {PureComponent} from 'react';

class PersonInfo extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            // age:this.props.person.age,
            // name:this.props.person.name
            info : {age:this.props.person.age, name:this.props.person.name}
        }
    }
    changeName = (e) => {
        // this.state.name = "song";
        // this.forceUpdate();
        //this.setState({name:e.target.value});
    }

    // changeAge = (e) => {
    //     this.setState({age:e.target.value});
    // }

    changeValue = (e) => {
        console.log(this.state.info);
        let name = e.target.name;
        let value = e.target.value;
        
        this.setState({info:{...this.state.info, [name]:value}});
        //this.setState({[name]:value});
    }

    render() {
        return(
            <div>
                이름:<input type="text" name="name" onChange={this.changeValue}/>&nbsp;&nbsp;
                <span>이름:{this.state.info.name}</span><br/>
                {/* <span>이름:{this.state.name}</span><br/> */}
                나이:<input type="text" name="age" onChange={this.changeValue}/>&nbsp;&nbsp;
                <span>나이:{this.state.info.age}</span>&nbsp;&nbsp;
                {/* <span>나이:{this.state.age}</span>&nbsp;&nbsp; */}
                {/* <button onClick={this.stateChange}>state 변경</button> */}
            </div>
        )
    }
}
export default PersonInfo;