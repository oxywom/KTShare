import './App.css';
import FPersonInfo from './FPersonInfo';

function App() {
  return (
    <div className="App">
      <FPersonInfo person={{age:20, name:"song"}}/>
    </div>
  );
}

export default App;
