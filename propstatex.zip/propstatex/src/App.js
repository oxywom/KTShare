import './App.css';
import PropCom from './PropCom';
import PersonInfo from './PersonInfo';
import PropsDataType from './PropsDataType';
import PropsBoolean from './PropsBoolean';
import PropsNode from './PropsNode';
function App() {
  return (
    <div>
      <h1>React Props Test</h1>
      <p>Props 적용하기</p>
      {/* <PropCom props_val='THIS IS PROPS'/>
      <PersonInfo person={{age:20, name:'hong'}}/> */}
      {/* <PropsDataType 
        String="react" 
        Number={200} 
        Boolean={1==1} 
        Array={[1,2,3]} 
        Obj={{age:10, name:'song'}}
        Function={console.log("function!")}/> */}
      {/* <PropsBoolean BooleanTrueFalse={false}/> */}
      <PropsNode>
        <span>node form App.js</span>
      </PropsNode>
    </div>
  );
}

export default App;
