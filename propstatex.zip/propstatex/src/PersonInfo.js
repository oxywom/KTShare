import React, {Component} from 'react';

class PersonInfo extends Component {
    render() {
        return(
            <>
                <div>{this.props.person.age}</div>
                <div>{this.props.person.name}</div>
            </>
        )
    }
}

export default PersonInfo;