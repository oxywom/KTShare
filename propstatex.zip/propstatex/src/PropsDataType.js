import React, {Component} from 'react';
import datatype from 'prop-types';

class PropsDataType extends Component {
    render() {
        let {String,
             Number,
             Boolean,
             Array,
             Obj,
             Function} = this.props;
        return(
            <div>
                <p>{String}</p>
                <p>{Number}</p>
                <p>{Boolean.toString()}</p>
                <p>{Array.toString()}</p>
                <p>{JSON.stringify(Obj)}</p>
                <p>{Function}</p>
            </div>
        )
    }
}
PropsDataType.propTypes = {
    String:datatype.string,
    Number:datatype.number,
    Boolean:datatype.bool,
    Array:datatype.array,
    Obj:datatype.object,
    Function:datatype.func,
}

export default PropsDataType;