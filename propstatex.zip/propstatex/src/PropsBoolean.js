import React, {Component} from 'react';
class PropsBoolean extends Component {
    render() {
        return(
            <div>{this.props.BooleanTrueFalse.toString()}</div>
        )
    }
}

export default PropsBoolean;