import React, {Component} from 'react';

class PropCom extends Component {
    render() {
        //let props_val = this.props.props_val;
        return (
            <div>{this.props.props_val}</div>
        )
    }
}

export default PropCom;